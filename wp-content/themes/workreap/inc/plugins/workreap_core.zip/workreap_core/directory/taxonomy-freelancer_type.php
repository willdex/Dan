<?php
/**
 *
 * The template used for displaying default Delivery time result
 *
 * @package   workreap
 * @author    Amentotech
 * @link      https://themeforest.net/user/amentotech/portfolio
 * @since 1.0
 */
global $wp_query;
get_header();
get_template_part( 'directory/freelancer-search');
get_footer();