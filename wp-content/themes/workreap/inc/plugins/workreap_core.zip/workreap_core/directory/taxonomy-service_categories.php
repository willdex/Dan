<?php
/**
 *
 * The template used for displaying default project category result
 *
 * @package   workreap
 * @author    Amentotech
 * @link      https://themeforest.net/user/amentotech/portfolio
 * @since 1.0
 */
global $wp_query;
get_header();
get_template_part("directory/services", "search");
