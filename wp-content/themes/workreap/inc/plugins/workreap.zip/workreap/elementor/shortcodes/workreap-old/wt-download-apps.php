<?php
/**
 * Shortcode
 *
 *
 * @package    Workreap
 * @subpackage Workreap/admin
 * @author     Amentotech <theamentotech@gmail.com>
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if( !class_exists('Workreap_Download_APP') ){
	class Workreap_Download_APP extends Widget_Base {

		/**
		 *
		 * @since    1.0.0
		 * @access   static
		 * @var      base
		 */
		public function get_name() {
			return 'wt_element_download_app';
		}

		/**
		 *
		 * @since    1.0.0
		 * @access   static
		 * @var      title
		 */
		public function get_title() {
			return esc_html__( 'Download APPS', 'workreap' );
		}

		/**
		 *
		 * @since    1.0.0
		 * @access   public
		 * @var      icon
		 */
		public function get_icon() {
			return 'eicon-download-button';
		}

		/**
		 *
		 * @since    1.0.0
		 * @access   public
		 * @var      category of shortcode
		 */
		public function get_categories() {
			return [ 'workreap-ele' ];
		}

		/**
		 * Register category controls.
		 * @since    1.0.0
		 * @access   protected
		 */
		protected function register_controls() {
			//Content
			$this->start_controls_section(
				'content_section',
				[
					'label' => esc_html__( 'Content', 'workreap' ),
					'tab' => Controls_Manager::TAB_CONTENT,
				]
			);
			
			$this->add_control(
				'image',
				[
					'type'      	=> Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
					'label'     	=> esc_html__( 'Upload Image', 'workreap' ),
					'description'   => esc_html__( 'Upload Image. leave it empty to hide.', 'workreap' ),
				]
			);
			
			$this->add_control(
				'title',
				[
					'type'      	=> Controls_Manager::TEXT,
					'label'     	=> esc_html__( 'Title', 'workreap' ),
					'description'   => esc_html__( 'Add title. leave it empty to hide.', 'workreap' ),
				]
			);
			
			$this->add_control(
				'sub_title',
				[
					'type'      	=> Controls_Manager::TEXT,
					'label'     	=> esc_html__( 'Sub Title', 'workreap' ),
					'description'   => esc_html__( 'Add subtitle. leave it empty to hide.', 'workreap' ),
				]
			);
			
			$this->add_control(
				'description',
				[
					'type'      	=> Controls_Manager::WYSIWYG,
					'label'     	=> esc_html__( 'Description', 'workreap' ),
					'description'   => esc_html__( 'Add description. leave it empty to hide.', 'workreap' ),
				]
			);
			
			$this->add_control(
				'logos',
				[
					'label'  => esc_html__( 'Logos', 'workreap' ),
					'type'   => Controls_Manager::REPEATER,
					'fields' => [
						[
							'name'  => 'image',
							'label' => esc_html__( 'Select logo', 'workreap' ),
							'type'      	=> Controls_Manager::MEDIA,
							'default' => [
								'url' => \Elementor\Utils::get_placeholder_image_src(),
							],
						],
						[
							'name'  => 'button_text',
							'label' => esc_html__( 'Add button text', 'workreap' ),
							'type'  => Controls_Manager::TEXT,
							'description'   => esc_html__( 'Add text to display button, it will override logo image and display simple button', 'workreap' ),
						],
						[
							'name'  => 'link_url',
							'label' => esc_html__( 'Button Url', 'workreap' ),
							'type'  => Controls_Manager::TEXT,
						],
						[
							'name'  => 'link_target',
							'label' => esc_html__( 'Link Target', 'workreap' ),
							'type'  => Controls_Manager::SELECT,
							'default' => '_blank',
							'options' => [
								'_blank' 	=> esc_html__('New Tab', 'workreap'),
								'_self' 	=> esc_html__('Current Tab', 'workreap'),
							],
						],
					],
					'default' => [],
				]
			);

			$this->end_controls_section();
		}

		/**
		 * Render shortcode
		 *
		 * @since 1.0.0
		 * @access protected
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();
			$image 	   = !empty($settings['image']['url']) ? $settings['image']['url'] : '';
			$title     = !empty($settings['title']) ? $settings['title'] : '';
			$sub_title = !empty($settings['sub_title']) ? $settings['sub_title'] : '';
			$desc  	   = !empty($settings['description']) ? $settings['description'] : '';
			$logos 	   = !empty($settings['logos']) ? $settings['logos'] : array();
			?>
			<div class="wt-sc-explore-cat wt-haslayout">
				<div class="row">
					<?php 
					if( !empty( $image ) ||
						!empty( $title ) ||
						!empty( $sub_title ) ||
						!empty( $desc ) ||
						!empty( $logos ) ) {
						?>
						<?php if( !empty( $image ) ) { ?>
							<div class="col-12 col-sm-12 col-md-6 col-lg-6 float-left">
								<figure class="wt-mobileimg">
									<img src="<?php echo esc_url($image); ?>" alt="<?php esc_attr_e('APP' ,'workreap') ?>">
								</figure>
							</div>
						<?php } ?>
						<?php 
						if( !empty( $title ) ||
							!empty( $sub_title ) ||
							!empty( $desc ) ||
							!empty( $logos ) ) {
							?>
							<div class="col-12 col-sm-12 col-md-6 col-lg-6 float-left">
								<div class="wt-experienceholder">
									<div class="wt-sectionhead">
										<?php if(!empty( $title )  || !empty( $sub_title )) { ?>
											<div class="wt-sectiontitle">
												<?php if( !empty($sub_title) ) { ?>
                                                    <span><?php echo esc_html( $sub_title ); ?></span>
												<?php } ?>
												<?php if( !empty( $title ) ) { ?>
													<h2><?php echo esc_html($title); ?></h2>
												<?php } ?>
											</div>
										<?php } ?>
										<?php if( !empty( $desc) ) { ?>
											<div class="wt-description">
												<?php echo wp_kses_post( wpautop( do_shortcode( $desc ) ) ); ?>
											</div>
										<?php } ?>
										<?php if( !empty( $logos ) ) { ?>
											<ul class="wt-appicon">
												<?php 
													foreach( $logos as $key => $logo ) { 
														$image  = !empty( $logo['image']['url'] ) ? $logo['image']['url'] : '';
														$url    = !empty( $logo['link_url'] ) ? $logo['link_url'] : '#';
														$button_text    = !empty( $logo['button_text'] ) ? $logo['button_text'] : '';
														$target = !empty( $logo['link_target'] ) ? $logo['link_target'] : '_blank';
														$buttonCalss	= !empty($button_text) ?  'wt-btn' : '';
														if( !empty( $image ) || !empty($button_text) ) { ?>
														<li>
															<a target="<?php echo esc_attr($target); ?>" class="<?php echo esc_attr($buttonCalss); ?>" href="<?php echo esc_url($url); ?>">
																<?php if( !empty( $button_text ) ) { ?>
																	<?php echo esc_attr($button_text);?>
																<?php }else if( !empty( $image ) ) {?>
																	<figure><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr($button_text); ?>"></figure>
																<?php } ?>
															</a>
														</li>
													<?php } ?>
												<?php } ?>
											</ul>
										<?php } ?>
									</div>
								</div>
							</div>
						<?php } ?>
					<?php } ?>
				</div>
			</div>
		<?php 
		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Workreap_Download_APP ); 
}